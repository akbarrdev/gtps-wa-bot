Dilarang menjual script ini dengan alasan apapun.
Jika kamu belum paham, silahkan lihat tutorial pemakaian di https://gtps.app/bot-tutorial.
Memiliki pertanyaan atau saran? Join discord gtps.app (https://discord.gg/Nq8NvdeXsm)

Edit config di configuration/bot-config.js dan gtps-config.js
Jika ingin mengubah tampilan bot, edit interface.js
Tekan Installation bat untuk menginstall bot.
Tekan Start bot untuk menjalankan bot.

index & iciro jgn di edit